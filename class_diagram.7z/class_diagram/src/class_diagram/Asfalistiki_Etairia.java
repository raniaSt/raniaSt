package class_diagram;

import java.util.*;

public class Asfalistiki_Etairia {
	private String Onoma;
	
	static ArrayList<Asfalistiki_Etairia> Katalogos_Asfalistikwn = new ArrayList<Asfalistiki_Etairia>();
	
	public Asfalistiki_Etairia(String Onoma1) {
		Onoma = Onoma1;
		Katalogos_Asfalistikwn.add(this);
	}

	public String getOnoma() {
		return Onoma;
	}

	public void setOnoma(String onoma) {
		Onoma = onoma;
	}
	
	public void printData() {
		System.out.println(Onoma);
	}
	
	public void Apostoli(Minima message) {
	//απαραίτητο για την επιλογή ασφαλιστικής εταιρείας στην οποία θα σταλεί το μήνυμα
		System.out.println("Minima has been sent to " + this.Onoma);
	}

}
