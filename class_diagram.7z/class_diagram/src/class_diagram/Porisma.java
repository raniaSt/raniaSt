package class_diagram;

import java.util.*;

public class Porisma {
	static ArrayList<Porisma> Katalogos_Porismatwn = new ArrayList<Porisma>();
	
	private String Keimeno;
	/*απαραίτητο προκειμένου να ξεχωρίζουν τα πορίσματα μεταξύ τους 
	και να μπορεί να κληθεί η printData()*/
	 
	public Porisma(String Keimeno1) {
		Keimeno = Keimeno1;
		Katalogos_Porismatwn.add(this);
	}
	
	public String getKeimeno() {
		return Keimeno;
	}
	
	public void setKeimeno(String keimeno) {
		Keimeno = keimeno;
	}

	public void printData() {
		System.out.println(Keimeno);
	}
}
