package class_diagram;

import java.util.*;
import java.time.LocalDate;

public class Anafora {
	String Eidos, Kwdikos_Praktora;
	LocalDate Arxh_Periodou, Telos_Periodou;
	int Arithmos_Paketou;

	static ArrayList<Anafora> Katalogos_Anaforwn = new ArrayList<Anafora>();

	public Anafora(String Eidos1, LocalDate Arxh_Periodou1, LocalDate Telos_Periodou1, int Arithmos_Paketou1, String Kwdikos_Praktora1) {
		Eidos = Eidos1;
		Arxh_Periodou = Arxh_Periodou1;
		Telos_Periodou = Telos_Periodou1;
		Arithmos_Paketou = Arithmos_Paketou1;
		Kwdikos_Praktora = Kwdikos_Praktora1;
		Katalogos_Anaforwn.add(this);
	}

	public String getEidos() {
		return Eidos;
	}

	public void setEidos(String eidos) {
		Eidos = eidos;
	}

	public String getKwdikos_Praktora() {
		return Kwdikos_Praktora;
	}

	public void setKwdikos_Praktora(String kwdikos_Praktora) {
		Kwdikos_Praktora = kwdikos_Praktora;
	}

	public LocalDate getArxh_Periodou() {
		return Arxh_Periodou;
	}

	public void setArxh_Periodou(LocalDate arxh_Periodou) {
		Arxh_Periodou = arxh_Periodou;
	}

	public LocalDate getTelos_Periodou() {
		return Telos_Periodou;
	}

	public void setTelos_Periodou(LocalDate telos_Periodou) {
		Telos_Periodou = telos_Periodou;
	}

	public int getArithmos_Paketou() {
		return Arithmos_Paketou;
	}

	public void setArithmos_Paketou(int arithmos_Paketou) {
		Arithmos_Paketou = arithmos_Paketou;
	}

	public void Lipsi_Anaforas() {}//Λήψη στον υπολογιστή του χρήστη

	public void printData(){
		System.out.println(Eidos);
		System.out.println(Arxh_Periodou);
		System.out.println(Telos_Periodou);
		System.out.println(Arithmos_Paketou);
		System.out.println(Kwdikos_Praktora);
	}

}
