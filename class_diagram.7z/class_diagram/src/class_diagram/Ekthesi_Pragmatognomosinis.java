package class_diagram;

import java.util.*;

public class Ekthesi_Pragmatognomosinis {
	static ArrayList<Ekthesi_Pragmatognomosinis> Katalogos_Ekthesewn = new ArrayList<Ekthesi_Pragmatognomosinis>();
	
	private String Onoma;
	
	public Ekthesi_Pragmatognomosinis(String Onoma1) {
		Onoma = Onoma1;
		Katalogos_Ekthesewn.add(this);
	}
	
	public String getOnoma() {
		return Onoma;
	}
	
	public void setOnoma(String onoma) {
		Onoma = onoma;
	}
	
	
	public void printData() {
		int i;
		
		System.out.println(Onoma);
		if(Minima.Katalogos_Minimatwn.size()>0) {
			System.out.println("Minimata:");
			for(i=0; i<Minima.Katalogos_Minimatwn.size(); i++)
				if(Minima.Katalogos_Minimatwn.get(i).getEk_Pragm() == this)
					Minima.Katalogos_Minimatwn.get(i).printData();
			System.out.println("\n------------------------");
		}
	}

}
