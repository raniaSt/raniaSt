package class_diagram;

import java.util.*;

public class Symvolaio {
	static ArrayList<Symvolaio> Katalogos_Symvolaiwn = new ArrayList<Symvolaio>();
	
	private Oxima Ox;
	/*απαραίτητο για τον συσχετισμό μεταξύ οχήματος και συμβολαίου
	και για την printData()*/
	
	public Symvolaio(Oxima Ox1) {
		Ox = Ox1;
		Katalogos_Symvolaiwn.add(this);
	}
	
	public Oxima getOx() {
		return Ox;
	}

	public void setOx(Oxima ox) {
		Ox = ox;
	}

	public void Diakopi() {
		Katalogos_Symvolaiwn.remove(this);
	}
	
	public void printData() {
		System.out.println(this.Ox.getArithmos_Kykloforias());
	}
	
}
