package class_diagram;

public class Enimerotiko_Keimeno {
	private String Keimeno;//απαραίτητο για την κλήση της printData() από την κλάση Minimata
	
	public Enimerotiko_Keimeno(String Keimeno1) {
		Keimeno = Keimeno1;
	}

	public String getKeimeno() {
		return Keimeno;
	}

	public void setKeimeno(String keimeno) {
		Keimeno = keimeno;
	}
	
}
