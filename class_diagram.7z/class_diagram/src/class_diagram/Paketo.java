package class_diagram;

import java.util.*;

public class Paketo {
	private String titlos;
	private float poso;
	private int arith_paketou;
	
	static ArrayList<Paketo> Katalogos_Paketwn = new ArrayList<Paketo>();
	
	public Paketo(String titlos1, float poso1, int arith_paketou1) {
		//Η εισαγωγή στοιχείων γίνεται μέσω του constructor
		titlos = titlos1;
		poso = poso1;
		arith_paketou = arith_paketou1;
		Katalogos_Paketwn.add(this);
	}

	public String getTitlos() {
		return titlos;
	}

	public void setTitlos(String titlos) {
		this.titlos = titlos;
	}

	public float getPoso() {
		return poso;
	}

	public void setPoso(float poso) {
		this.poso = poso;
	}

	public int getArith_paketou() {
		return arith_paketou;
	}

	public void setArith_paketou(int arith_paketou) {
		this.arith_paketou = arith_paketou;
	}
	
	public void printData() {
		System.out.println(titlos);
		System.out.println(poso);
		System.out.println(arith_paketou);
	}
}
