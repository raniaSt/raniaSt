package class_diagram;

import java.util.*;

public class Oxima {
	private String Arithmos_Kykloforias, Marka, Montelo, Xrwma;
	int Kivika_Ekatosta;
	Pelatis pel;
	
	static ArrayList<Oxima> Katalogos_Oximatwn = new ArrayList<Oxima>();
	
	public Oxima(String Arithmos_Kykloforias1, String Marka1, String Montelo1, int Kivika_Ekatosta1, String Xrwma1, Pelatis pel1) {
		//Αποθήκευση στοιχείων εντός του constructor 
		Arithmos_Kykloforias = Arithmos_Kykloforias1;
		Marka = Marka1;
		Montelo = Montelo1;
		Kivika_Ekatosta = Kivika_Ekatosta1;
		Xrwma = Xrwma1;
		pel = pel1;
		Katalogos_Oximatwn.add(this);
	}

	public String getArithmos_Kykloforias() {
		return Arithmos_Kykloforias;
	}

	public void setArithmos_Kykloforias(String arithmos_Kykloforias) {
		Arithmos_Kykloforias = arithmos_Kykloforias;
	}

	public String getMarka() {
		return Marka;
	}

	public void setMarka(String marka) {
		Marka = marka;
	}

	public String getMontelo() {
		return Montelo;
	}

	public void setMontelo(String montelo) {
		Montelo = montelo;
	}

	public String getXrwma() {
		return Xrwma;
	}

	public void setXrwma(String xrwma) {
		Xrwma = xrwma;
	}

	public int getKivika_Ekatosta() {
		return Kivika_Ekatosta;
	}

	public void setKivika_Ekatosta(int kivika_Ekatosta) {
		Kivika_Ekatosta = kivika_Ekatosta;
	}
	
	public Pelatis getPel() {
		return pel;
	}

	public void setPel(Pelatis pel) {
		this.pel = pel;
	}

	public void printData() {
		System.out.println(Arithmos_Kykloforias + " " + Marka + " " + Montelo +
				" " + Kivika_Ekatosta + " " + Xrwma);
	}

}
