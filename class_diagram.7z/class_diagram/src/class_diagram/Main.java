package class_diagram;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		String pass1;
		int i;

		Ekthesi_Pragmatognomosinis ek1 = new Ekthesi_Pragmatognomosinis("Ek1");
		System.out.println("Ekthesi Pragmatognomosinis " + ek1.getOnoma() + " has been created");
		Praktoras pr1 = new Praktoras("Georgiadis");
		System.out.println("Praktoras " + pr1.getOnoma() + " has been created");
		pr1.Apostoli(ek1);
		System.out.println("--------------------------------------------------");
		
		Ekthesi_Pragmatognomosinis ek2 = new Ekthesi_Pragmatognomosinis("Ek2");
		System.out.println("Ekthesi Pragmatognomosinis " + ek2.getOnoma() + " has been created");
		Praktoras pr2 = new Praktoras("Kaskalis");
		System.out.println("Praktoras " + pr2.getOnoma() + " has been created");
		pr2.Apostoli(ek2);
		System.out.println("--------------------------------------------------");
		
		
		Asfalistiki_Etairia Ins1 = new Asfalistiki_Etairia("Ins1");
		System.out.println("Asfalistiki Etairia " + Ins1.getOnoma() + " has been created");
		Asfalistiki_Etairia Ins2 = new Asfalistiki_Etairia("Ins2");
		System.out.println("Asfalistiki Etairia " + Ins2.getOnoma() + " has been created");
		
		Deltio_Symvantos ds1 = new Deltio_Symvantos("Deltio1");
		System.out.println("New Deltio Symvantos has been created");
		Enimerotiko_Keimeno enKeim1 = new Enimerotiko_Keimeno("Keimeno1");
		System.out.println("New Enimerotiko Keimeno has been created");
		Minima m1 = new Minima(ek2, ds1, enKeim1);//Πράκτορας προς ασφαλιστική εταιρεία
		Ins1.Apostoli(m1);
		System.out.println("--------------------------------------------------");
		
		Pelatis pel1 = new Pelatis("Papadopoulos", "Georgios", LocalDate.of(1999, 12, 10), 1234);
		System.out.println("Pelatis " + pel1.getEpwnymo() + " " + pel1.getOnoma() + " has been created");
		Oxima o1 = new Oxima("MYZ1234", "OPEL", "ASTRA", 1234, "GKRI", pel1);
		System.out.println("Oxima " + o1.getArithmos_Kykloforias() + " has been created");
		Oxima o2 = new Oxima("ABC4321", "BMW", "MODEL", 5678, "KOKKINO", pel1);
		System.out.println("Oxima " + o2.getArithmos_Kykloforias() + " has been created");
		Symvolaio S1 = new Symvolaio(o1);
		System.out.println("New symvolaio has been created for Oxima " + o1.getArithmos_Kykloforias());
		Symvolaio S2 = new Symvolaio(o2);
		System.out.println("New symvolaio has been created for Oxima " + o2.getArithmos_Kykloforias());
		S1.Diakopi();
		System.out.println("Symvolaio for Oxima " + S1.getOx().getArithmos_Kykloforias() + " has been removed");
		System.out.println("--------------------------------------------------");
		
		
		Pelatis pel2 = new Pelatis("Stavri", "Ourania", LocalDate.of(2004, 10, 13), 3459);
		Oxima o3 = new Oxima("EUR7890", "OPEL", "ASTRA", 1236, "MPLE", pel2);
		System.out.println("Oxima " + o3.getArithmos_Kykloforias() + " has been created");
		System.out.println("Pelatis " + pel2.getEpwnymo() + " " + pel2.getOnoma() + " has been created");
		Symvolaio S3 = new Symvolaio(o3);
		System.out.println("New symvolaio has been created for Oxima " + o3.getArithmos_Kykloforias());
		System.out.println("--------------------------------------------------");
		
		Xrhsths x1 = new Xrhsths("Giannouli", "giannouligeorgia123@gmail.com", "1319@!_Hell0");
		System.out.println("Xrhsths " + x1.getOnoma() + " has been created");
		Xrhsths x2 = new Xrhsths("Ioannou", "ioannounick@gmail.com", "n1cK04");
		System.out.println("Xrhsths " + x2.getOnoma() + " has been created");
		pass1 = "nick2004";
		System.out.println("Xrhsths " + x2.getOnoma() + " typed password '" + pass1 + "'");
		if(x2.Elegxos_Kwdikou(pass1))
			System.out.println("Right password!");
		else
			System.out.println("Wrong password!");
		pass1 = "n1cK04";
		System.out.println("Xrhsths " + x2.getOnoma() + " typed password '" + pass1 + "'");
		if(x2.Elegxos_Kwdikou(pass1))
			System.out.println("Right password!");
		else
			System.out.println("Wrong password!");
		x2.Kataxwrisi("N1Ck2004!");
		System.out.println(x2.getOnoma() + "'s password has changed");
		System.out.println("--------------------------------------------------");
		
		Anafora an1 = new Anafora("Nea", LocalDate.of(2024, 1, 1), LocalDate.of(2024, 12, 31), 01, "a123");
		System.out.println("New Anafora has been created");
		System.out.println("--------------------------------------------------");
		
		Paketo p1 = new Paketo("Paketo1", 30, 3);
		System.out.println("Paketo " + p1.getTitlos() + " has been created");
		Paketo p2 = new Paketo("Paketo2", 50, 6);
		System.out.println("Paketo " + p2.getTitlos() + " has been created");
		Paketo p3 = new Paketo("Paketo3", 65, 13);
		System.out.println("Paketo " + p3.getTitlos() + " has been created");
		System.out.println("--------------------------------------------------");
		
		Porisma por1 = new Porisma("Porisma1");
		System.out.println("Porisma " + por1.getKeimeno() + " has been created");
		System.out.println("--------------------------------------------------");
		
		Protasi_Asfalisis pa1 = new Protasi_Asfalisis("Proatsi1");
		System.out.println("Protasi Asfalisis " + pa1.getKeimeno() + " has been created");
		Protasi_Asfalisis pa2 = new Protasi_Asfalisis("Protasi2");
		System.out.println("Protasi Asfalisis " + pa2.getKeimeno() + " has been created");
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos Ekthesewn Pragmatognomosinis:");
		for(i=0; i<Ekthesi_Pragmatognomosinis.Katalogos_Ekthesewn.size(); i++)
			Ekthesi_Pragmatognomosinis.Katalogos_Ekthesewn.get(i).printData();
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos Praktorwn:");
		for(i=0; i<Praktoras.Katalogos_Praktorwn.size(); i++)
			Praktoras.Katalogos_Praktorwn.get(i).printData();
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos Asfalistikwn Etairiwn:");
		for(i=0; i<Asfalistiki_Etairia.Katalogos_Asfalistikwn.size(); i++)
			Asfalistiki_Etairia.Katalogos_Asfalistikwn.get(i).printData();
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos Pelatwn:");
		for(i=0; i<Pelatis.Katalogos_Pelatwn.size(); i++)
			Pelatis.Katalogos_Pelatwn.get(i).printData();
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos Symvolaiwn:");
		for(i=0; i<Symvolaio.Katalogos_Symvolaiwn.size(); i++)
			Symvolaio.Katalogos_Symvolaiwn.get(i).printData();
		System.out.println("--------------------------------------------------");
		
		System.out.println("Katalogos_Xrhstwn:");
		for(i=0; i<Xrhsths.Katalogos_Xrhstwn.size(); i++)
			Xrhsths.Katalogos_Xrhstwn.get(i).printData();
	}
}
