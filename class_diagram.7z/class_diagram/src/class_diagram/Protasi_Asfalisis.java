package class_diagram;

import java.util.*;

public class Protasi_Asfalisis {
	static ArrayList<Protasi_Asfalisis> Katalogos_Protasewn = new ArrayList<Protasi_Asfalisis>();
	
	private String Keimeno;
	/*απαραίτητο προκειμένου να ξεχωρίζουν οι προτάσεις μεταξύ τους
	και για την υλοποίηση της μεθόδου printData()*/
	
	public Protasi_Asfalisis(String Keimeno1) {
		Keimeno = Keimeno1;
		Katalogos_Protasewn.add(this);
	}
	
	public String getKeimeno() {
		return Keimeno;
	}
	
	public void setKeimeno(String keimeno) {
		Keimeno = keimeno;
	}

	public void printData() {
		System.out.println(Keimeno);
	}

}
