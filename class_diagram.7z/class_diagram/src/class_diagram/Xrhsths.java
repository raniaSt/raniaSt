package class_diagram;

import java.util.*;

public class Xrhsths {
	private String Onoma, Email, Password;
	
	static ArrayList<Xrhsths> Katalogos_Xrhstwn = new ArrayList<Xrhsths>();
	
	public Xrhsths(String Onoma1, String Email1, String Password1) {
		Onoma = Onoma1;
		Email = Email1;
		Password = Password1;//attribute αντί για κλάση, συνδέεται άμεσα με τον χρήστη
		Katalogos_Xrhstwn.add(this);
	}

	public String getOnoma() {
		return Onoma;
	}

	public void setOnoma(String onoma) {
		Onoma = onoma;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public boolean Elegxos_Kwdikou(String Kwd) {
		if(Kwd==this.Password)
			return true;
		return false;
	}
	
	public void Kataxwrisi(String Neos_Kwdikos) {
		Password = Neos_Kwdikos;
	}
	
	public void printData() {
		System.out.println(Onoma + " " + Email + " " + Password);
	}

}
