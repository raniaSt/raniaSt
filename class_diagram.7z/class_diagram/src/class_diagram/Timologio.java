package class_diagram;

public class Timologio {
	public Timologio() {}

}
