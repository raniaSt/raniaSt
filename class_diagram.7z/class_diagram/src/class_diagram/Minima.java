package class_diagram;

import java.util.*;

public class Minima {
	private Ekthesi_Pragmatognomosinis reference1;
	private Deltio_Symvantos reference2;
	private Enimerotiko_Keimeno reference3;
	Ekthesi_Pragmatognomosinis Ek_Pragm;
	Deltio_Symvantos Del_Symv;
	Enimerotiko_Keimeno Enim_Keim;
	
	static ArrayList<Minima> Katalogos_Minimatwn = new ArrayList<Minima>();
	
	public Minima(Ekthesi_Pragmatognomosinis Ek_Pragm1, Deltio_Symvantos Del_Symv1 , Enimerotiko_Keimeno Enim_Keim1) {
	//Η επισύναψη γίνεται εντός του constructor	
		Ek_Pragm = Ek_Pragm1;
		Del_Symv = Del_Symv1;
		Enim_Keim = Enim_Keim1;
		Katalogos_Minimatwn.add(this);
	}
	
	
	public Asfalistiki_Etairia Epilogi_Asfalistikis(String Onoma1){
		int i;
		
		for(i=0; i<Asfalistiki_Etairia.Katalogos_Asfalistikwn.size(); i++) {
		//Αναζήτηση στον κατάλογο για το Onoma1 και επιστροφή του αντικειμένου Ασφαλιστικής Εταιρείας
			if(Asfalistiki_Etairia.Katalogos_Asfalistikwn.get(i).getOnoma()==Onoma1)
				return Asfalistiki_Etairia.Katalogos_Asfalistikwn.get(i);
		}
		return null;
	}/*Δεν έχει κάποια λειτουργικότητα στο συγκεκριμένο πρόγραμμα.
	Ωστόσο, σε GUI, θα γινόταν επιλογή του String "Ins1" πχ από τα κουμπιά
	και το σύστημα θα αναζητούσε αυτό το Onoma στον κατάλογο ασφαλιστικών για να βρει το αντικείμενο Ins1, 
	στο οποίο στη συνέχεια θα έστελνε το μήνυμα, με τη μέθοδο Apostoli(Minima message) της κλάσης Asfalistikh_Etairia*/
	
	
	
	public void printData() {
		if(Ek_Pragm!=null)
			System.out.print("(" + Ek_Pragm.getOnoma());
		else
			System.out.print("(null");
		if(Del_Symv!=null)
			System.out.print(", " + Del_Symv.getTitle());
		else
			System.out.print(", null");
		if(Enim_Keim!=null)
			System.out.print(", " +	Enim_Keim.getKeimeno() + ")");
		else
			System.out.print(", null)");
			
	}

	public Ekthesi_Pragmatognomosinis getEk_Pragm() {
		return Ek_Pragm;
	}

	public void setEk_Pragm(Ekthesi_Pragmatognomosinis ek_Pragm) {
		Ek_Pragm = ek_Pragm;
	}

	public Deltio_Symvantos getDel_Symv() {
		return Del_Symv;
	}

	public void setDel_Symv(Deltio_Symvantos del_Symv) {
		Del_Symv = del_Symv;
	}

	public Enimerotiko_Keimeno getEnim_Keim() {
		return Enim_Keim;
	}

	public void setEnim_Keim(Enimerotiko_Keimeno enim_Keim) {
		Enim_Keim = enim_Keim;
	}

}
