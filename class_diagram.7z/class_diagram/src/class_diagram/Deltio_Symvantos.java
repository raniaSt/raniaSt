package class_diagram;

public class Deltio_Symvantos {
	//κλάση απαραίτητη για την επισύναψη σε μήνυμα
	private String title; //απαραίτητο για την κλήση της printData() από την κλάση Minimata
	
	public Deltio_Symvantos(String title1) {
		title = title1;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
