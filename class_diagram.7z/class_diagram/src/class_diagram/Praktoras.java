package class_diagram;

import java.util.*;

public class Praktoras {
	private String Onoma;
	static ArrayList<Praktoras> Katalogos_Praktorwn = new ArrayList<Praktoras>();
	
	public Praktoras(String Onoma1){
		Onoma = Onoma1;
		Katalogos_Praktorwn.add(this);
	}

	public String getOnoma() {
		return Onoma;
	}

	public void setOnoma(String onoma) {
		Onoma = onoma;
	}
	
	public void Apostoli(Ekthesi_Pragmatognomosinis Ekth_Pragm) {
		Minima message = new Minima(Ekth_Pragm, null, null);//Πραγματογνώμονας προς πράκτορα
		System.out.println("New Minima has been created");
		System.out.println(Ekth_Pragm.getOnoma() + " has been sent to " + this.Onoma);
	}
	
	public void printData() {
		System.out.println(Onoma);
	}

}
