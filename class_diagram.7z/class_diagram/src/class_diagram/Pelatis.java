package class_diagram;

import java.util.*;
import java.time.LocalDate;

public class Pelatis {
	String Epwnymo, Onoma, Dieuthinsi;
	LocalDate Hmer_Gennisis;
	int Ar_Diplomatos_Odigisis;

	static ArrayList<Pelatis> Katalogos_Pelatwn = new ArrayList<Pelatis>();

	public Pelatis(String Epwnymo1, String Onoma1, LocalDate Hmer_Gennisis1, int Ar_Diplomatos_Odigisis1) {
		//Αποθήκευση των στοιχείων εντός του constructor
		Epwnymo = Epwnymo1;
		Onoma = Onoma1;
		Hmer_Gennisis = Hmer_Gennisis1;
		Ar_Diplomatos_Odigisis = Ar_Diplomatos_Odigisis1;
		Katalogos_Pelatwn.add(this);
	}

	public String getEpwnymo() {
		return Epwnymo;
	}

	public void setEpwnymo(String epwnymo) {
		Epwnymo = epwnymo;
	}

	public String getOnoma() {
		return Onoma;
	}

	public void setOnoma(String onoma) {
		Onoma = onoma;
	}

	public String getDieuthinsi() {
		return Dieuthinsi;
	}

	public void setDieuthinsi(String dieuthinsi) {
		Dieuthinsi = dieuthinsi;
	}

	public LocalDate getHmer_Gennisis() {
		return Hmer_Gennisis;
	}

	public void setHmer_Gennisis(LocalDate hmer_Gennisis) {
		Hmer_Gennisis = hmer_Gennisis;
	}

	public int getAr_Diplomatos_Odigisis() {
		return Ar_Diplomatos_Odigisis;
	}

	public void setAr_Diplomatos_Odigisis(int ar_Diplomatos_Odigisis) {
		Ar_Diplomatos_Odigisis = ar_Diplomatos_Odigisis;
	}
	
	public void printData() {
		int i;
		
		System.out.println(Epwnymo + " " + Onoma + " " + Hmer_Gennisis + " " + Ar_Diplomatos_Odigisis);
		if(Oxima.Katalogos_Oximatwn.size()>0) {
			System.out.println("Oximata:");
			for(i=0; i<Oxima.Katalogos_Oximatwn.size(); i++)
				if(Oxima.Katalogos_Oximatwn.get(i).getPel()==this)
				Oxima.Katalogos_Oximatwn.get(i).printData();
		}
		System.out.println("------------------------");
	}

}
